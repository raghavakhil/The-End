/// <reference path = "mobile.ts" />
/// <reference path = "basic.ts" />
/// <reference path = "smart.ts" />

var details =[
    {
        "mobileId":1,
        "mobileName":"Honor 7A",
        "mobileCost":10000,
        "mobileType":"Android"
    },
    {
        "mobileId":2,
        "mobileName":"One Plus 6",
        "mobileCost":540000,
        "mobileType":"Android"
    }]
function PrintDetails(phone){
    phone. printMobileDetails();
}

var basic = new Mobile.BasicPhone();
basic.mobileId=details[1].mobileId;
basic.mobileName=details[1].mobileName;
basic.mobileCost=details[1].mobileCost;
basic.mobileType=details[1].mobileType;
PrintDetails(basic);

var smart = new Mobile.SmartDetails();
smart.mobileId=details[0].mobileId;
smart.mobileName=details[0].mobileName;
smart.mobileCost=details[0].mobileCost;
smart.mobileType=details[0].mobileType;
PrintDetails(smart);