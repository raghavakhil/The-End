var Mobile;
(function (Mobile_1) {
    var Mobile = /** @class */ (function () {
        function Mobile() {
        }
        Mobile.prototype.printMobileDetails = function () {
            console.log(this.mobileId, this.mobileName, this.mobileCost);
        };
        return Mobile;
    }());
    Mobile_1.Mobile = Mobile;
})(Mobile || (Mobile = {}));
