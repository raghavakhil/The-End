import { Component } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'JSON data fetching into table';
  constructor (private httpService: HttpClient) { }
  bookArray: string [];

  ngOnInit () {
    this.httpService.get('./assets/booklist.json').subscribe(
      data => {
        this.bookArray = data as string [];	 
      },
     
    )}
}
