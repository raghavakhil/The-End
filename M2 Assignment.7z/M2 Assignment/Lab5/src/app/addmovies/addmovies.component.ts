import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-addmovies',
  templateUrl: './addmovies.component.html',
  styleUrls: ['./addmovies.component.css']
})
export class AddmoviesComponent implements OnInit {

  genres=['Drama','Fiction','Satire'];
  pattern1="^[A-Za-z0-9_-]{1,25}$";
  pattern2="^[0-9]+(.[0-9]{1,2})?$";
  constructor() { }

  ngOnInit() {
  }

}
