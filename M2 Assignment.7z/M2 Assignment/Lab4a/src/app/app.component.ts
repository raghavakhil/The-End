import { Component, OnInit } from '@angular/core';
import { appService } from './appService'
import { DataStruct } from './DataStruct'

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Pipes and Filters';
  public datalist:DataStruct[] = [];
  constructor(private user:appService){}

  ngOnInit(){
    this.user.getData().subscribe(data => this.datalist=data);
    console.log(this.datalist)
  }


}