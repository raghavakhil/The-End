import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { appService } from './appService'
import { HttpClientModule } from '@angular/common/http';

import {appPipe} from './appFilter.pipe';
import { AppComponent } from './app.component';
import { FormsModule }   from '@angular/forms';
@NgModule({
  declarations: [
    AppComponent,
    appPipe
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    FormsModule

  ],
  providers: [appService],
  bootstrap: [AppComponent]
})
export class AppModule { }