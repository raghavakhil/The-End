import { Pipe, PipeTransform, Injectable } from '@angular/core';

@Pipe({name: 'Filter'})

export class appPipe implements PipeTransform {
  transform(value: any[], a: string,b: string): any {

     let list:string=a?a.toLocaleLowerCase():null
     return list?value.filter((book:any)=>
     book[b].toString().toLocaleLowerCase().indexOf(list)!=-1):value;
     

}}