export interface DataStruct{
    Id:number,
    Title:string,
    Author:string,
    Year:number
}