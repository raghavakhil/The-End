import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'app-interpolation',
  templateUrl: './interpolation.component.html',
  styleUrls: ['./interpolation.component.css']
})
export class InterpolationComponent implements OnInit {
  ID:number;
  Name:string;
  Salary:number;
  Department:string;

add(){
  alert(this.ID+" "+this.Name+" "+this.Salary+" "+this.Department);
}

  constructor() { }

  ngOnInit() {
  }

}
