import { Component, OnInit } from '@angular/core';
import {NgForm} from '@angular/forms'
@Component({
  selector: 'app-lab3',
  templateUrl: './lab3.component.html',
  styleUrls: ['./lab3.component.css']
})
export class Lab3Component implements OnInit {
Id:number;
name:string;
Cost:number;
Online:string;
category:string;
Store:string;
employee:any;
categories=['Grocery', 'Mobile', 'Electronics','Cloths'];


submitEmpForm(employee:NgForm){
  console.log(this.Id+" "+this.name+" "+this.Cost+" "+this.Online+" "+this.category+" "+this.store);

}
  constructor() { }

  ngOnInit() {
  }
  store:any=[];
test(event){
this.store.push(event.target.defaultValue);
}
}
