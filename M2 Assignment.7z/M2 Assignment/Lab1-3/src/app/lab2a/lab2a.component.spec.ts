import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Lab2aComponent } from './lab2a.component';

describe('Lab2aComponent', () => {
  let component: Lab2aComponent;
  let fixture: ComponentFixture<Lab2aComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Lab2aComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Lab2aComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
