import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Asnmnt2Component } from './asnmnt2.component';

describe('Asnmnt2Component', () => {
  let component: Asnmnt2Component;
  let fixture: ComponentFixture<Asnmnt2Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Asnmnt2Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Asnmnt2Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
