import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'app-asnmnt2',
  templateUrl: './asnmnt2.component.html',
  styleUrls: ['./asnmnt2.component.css']
})
export class Asnmnt2Component implements OnInit {
 d:any;
 u:any;
 emp:any;
 ID:number;
 Name:string;
 Salary:number;
 Department:string;
  empId:number;
  empName:string;
  empSal:number;
  empDep:string;
  uId:number;
  uName:string;
  uSalary:number;
  uDepartment:string;
  change:any;
public employee:any= [
  {empId:1001,empName:"Rahul",empSal:9000,empDep:"Java"},
  {empId:1002,empName:"Sachin",empSal:19000,empDep:"OraApps"},
  {empId:1003,empName:"Vikash",empSal:29000,empDep:"BI"},
];
add1(){
  let emp:any={empId:this.ID,empName:this.Name,empSal:this.Salary,empDep:this.Department}

  this.employee.push(emp);
}
update(u){
  this.uId=u.empId;
  this.uName=u.empName;
  this.uSalary=u.empSal;
  this.uDepartment=u.empDep;
  this.change=u;
}
updateEmployee(){
  this.change.empId=this.uId;
  this.change.empName=this.uName;
  this.change.empSal=this.uSalary;
  this.change.empDep=this.uDepartment;
}
delete(d){
  this.employee.splice(d,1);
}
  constructor() { }

  ngOnInit() {
  }

}