import { Component } from '@angular/core';

import { InterpolationComponent } from './Lab1/interpolation.component';
import { Asnmnt2Component } from './Lab2/asnmnt2.component';
import { Lab2aComponent } from './lab2a/lab2a.component';
import { Lab3Component } from './lab3/lab3.component';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
 
 title="Angular 2 Operation";

}
