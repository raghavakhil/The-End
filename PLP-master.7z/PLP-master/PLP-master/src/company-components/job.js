import React, { Component } from 'react';
import '../App.css';
import axios from 'axios';
import Applicant from './applicant';

const HOST = 'http://10.102.52.210:8080';
class CompanyJobComponent extends Component {
  constructor(props) {
    super(props);
    this.state={
        applicantList: [],
        applySts: "APPLY",
        followSts: "FOLLOW",        
        applicantCount: {},
        show: false,
        display: "none",
    }    
  }
  componentWillMount(){

  }

    // changeShow(){
       
    //     if(this.state.display === "none")
    //         this.setState({display: "block"});
    //     else this.setState({display: "none"});
    // }

    //getting applicant-list count for particular job of a particular company
    getApplicantCount(companyId, jobId) {
        axios.post(HOST + '/orgs/applicant-count/', { "companyId": companyId, "jobId": jobId }).then(response => {
            //console.log("getApplicantCount", response.data)
            this.setState({applicantCount: response.data});
            //return response.data;
        }).catch(function (error) {
            console.log(error);
        });
    }

  //getting applicant-list for particular job of a particular company
  
    getApplicantList(companyId, jobId) {
        axios.post(HOST + '/orgs/applicant-list/', { "companyId": companyId, "jobId": jobId }).then(response => {       
            this.setState({applicantList: response.data});            
        }).catch(function (error) {
            console.log(error);
        });        
    }
//   remove(companyId, jobId){
//       axios.post(HOST + '/orgs/removeJob/', { "companyId": companyId, "jobId": jobId }).then(response => {
//           //console.log(response.data)
//           alert("job Deleted");
//           //return response.data;
//       }).catch(function (error) {
//           console.log(error);
//       });
//       window.open('/cviewjobs', '_self');
//   }
  handleApplicant(companyId, jobId){
     // this.changeShow();
      console.log(companyId, jobId);
      this.getApplicantList(companyId, jobId);
      this.getApplicantCount(companyId, jobId);        
      //window.open('/applicants', '_self');
  }
render() {
    //   if(this.props.states.userId)
    //console.log("In Job", this.props.states.company.companyID);
    let applicant;
        if (this.state.applicantList) {
            applicant = this.state.applicantList.map(todo => {                
                return (
                    <Applicant applicant={todo}/>
                );
            }); 
        }
    return (
      <div className="jobList">
          <div className="float-left">
              <p><b>Job Position:</b> {this.props.job.position}</p>
          </div>          
          <div className="float-none">
              <p><b>Last Date to Apply:</b> {this.props.job.lastDate}</p>
          </div>
          <div className="float-right">
              {/*<button className="btn btn-success" onClick={this.handleApplicant.bind(this, this.props.states.company.companyID, this.props.job.jobId)}> SEE APPLICANTS</button>*/}

              <button className="btn btn-success" onClick={this.handleApplicant.bind(this, this.props.states.company.companyID, this.props.job.jobId)}> SEE APPLICANTS</button>

              {/*<button className="btn btn-danger btn-job" onClick={this.remove.bind(this, this.props.states.company.companyID, this.props.job.jobId)}>REMOVE</button>*/}
          </div>
          <div id="showApplicants" style={{display: this.state.display}}>
              <h4><b>Total Applicants: {this.state.applicantCount.length}</b></h4>
              <ul>
                 {applicant}
              </ul>
          </div>
      </div>
    );
  }
}

export default CompanyJobComponent;
