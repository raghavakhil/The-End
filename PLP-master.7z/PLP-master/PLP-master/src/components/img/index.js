import img from "./img";
export default img;
