import "./img.css";
import React from "react";

function template() {
  return (
    <div className="img">
      <h1>img</h1>
    </div>
  );
};

export default template;
