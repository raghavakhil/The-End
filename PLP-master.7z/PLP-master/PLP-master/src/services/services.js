/**
 * @Author: Kameshwar
 */
import axios from 'axios';
import $ from 'jquery';
const HOST = 'http://10.102.52.210:8080';
class Service {





  //get particular company details
    // getCompanyDetails(companyId) {
    //     $.ajax({
    //         url: HOST+'/orgs/get/',
    //         dataType: 'text',
    //         contentType: 'application/json',
    //         cache: false,
    //         crossDomain: true,
    //         data: JSON.stringify({"companyId": companyId}),
    //         type: 'POST',
    //         success: function (data) {
    //             // this.setState({ user: data }, function () {
    //             //     console.log(this.state);
    //             // });
    //             console.log("Data", data);
    //             return data;
    //         }.bind(this),
    //         error: function (xhr, status, err) {
    //             console.log(err);
    //         }
    //     });           
    //  }


    //get particular company details
     getCompanyDetails(companyId) {
         
        axios.post(HOST + '/orgs/get/', { "companyId": companyId }).then(response => {
            console.log("getCompanyDetails",response.data[0]);
            return response.data[0];
        }).catch(function (error) {
            console.log(error);
        });            
    }

    //get list of all jobs details for a particular company
    allJobListOfCompany(companyId) {
        axios.post(HOST + '/orgs/getJobList/', { "companyId": companyId }).then(response => {

            console.log("allJobListOfCompany", response.data);
            return response.data;
        }).catch(function (error) {
            console.log("error",error);
        });
    }


    //get particular job details for a particular company
    getJobDetails(companyId, jobId) {
        axios.post(HOST + '/orgs/getJob/', { "companyId": companyId, "jobId": jobId }).then(response => {

            console.log("getJobDetails",response.data);
            return response.data;
        }).catch(function (error) {
            console.log(error);
        });
    }


    //add particular job details for a particular company    
    addjobDetails() {
        axios.post(HOST + '/orgs/postJob/', { companyId: "C006", jobId: "J008", position: "Analyst A5", timestamp: "2015-12-21T00:00:00Z", lastDate: "2018-09-28T00:00:00Z" }).then(response => {

            console.log(response.data)
            return response.data;
        }).catch(function (error) {
            console.log(error);
        });
    }



    //removing particular job for a particular company

    //Problem in Node as data should be send as a response but only status is coming
    removeJob() {
        axios.post(HOST + '/orgs/removeJob/', { companyId: "C006", jobId: "J008" }).then(response => {
            console.log(response.data)
            return response.data;
        }).catch(function (error) {
            console.log(error);
        });
    }

    //adding post for a particular company

    //commented becz it is again n again post on refreshing
    addNewPost() {
        axios.post(HOST + '/orgs/add-post/', { companyId: "C006", postId: "P0010", content: "Kameshwar'sJob" }).then(response => {
            console.log(response.data)
            return response.data;
        }).catch(function (error) {
            console.log(error);
        });
    }



    //getting applicant-list for particular job of a particular company
    getApplicantList(companyId, jobId) {
        axios.post(HOST + '/orgs/applicant-list/', { "companyId": companyId, "jobId": jobId }).then(response => {
            console.log("getApplicantList", response.data)
            return response.data;
        }).catch(function (error) {
            console.log(error);
        });
    }


    //getting applicant-list count for particular job of a particular company
    getApplicantCount(companyId, jobId) {
        axios.post(HOST + '/orgs/applicant-count/', { "companyId": companyId, "jobId": jobId }).then(response => {
            console.log("getApplicantCount", response.data)
            return response.data;
        }).catch(function (error) {
            console.log(error);
        });
    }

    //Adding applicant to applicant-list 
    addApplicant(companyId, jobId, userId) {
        axios.post(HOST + '/orgs/add-applicant/', { "companyId": companyId, "jobId": jobId, "applicant": userId }).then(response => {
            console.log("addApplicant", response.data)
            return response.data;
        }).catch(function (error) {
            console.log(error);
        });
    }

}

export default Service;