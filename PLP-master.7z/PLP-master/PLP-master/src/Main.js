import React, { Component } from 'react';
import App from './App';
import JobListComponent from './components/job-list';
import './App.css';
import { BrowserRouter as Router, Switch, Route } from 'react-router-dom';
//import CompanyProfile from './components/company-profile';
// import CompanyUserProfile from './company-components/profile';
import MainCompanyComponent from './company-components/main';
import CompanyJobListComponent from './company-components/job-list';
import Header from './header';
import Footer from './footer';
import './header.css';

class Main extends Component {
 render() {
  return (
      <div>
      
        <Header />
     
      <div className="container" style={{marginTop:"50px"}}>
        <Router >
          <Switch>
            <Route exact path='/' component={App} />    
            <Route exact path='/viewjobs/:id' component={JobListComponent} />
            <Route exact path='/company' component={MainCompanyComponent} />
            <Route exact path='/cviewjobs/:id' component={CompanyJobListComponent} />
            {/*<Route exact path='/applicants' component={ApplicantComponent} />*/}
            <Route exact path='/profile' component={App} />
          </Switch>
        </Router>

        </div>
      
        <Footer />
      
   </div>
    );
  }
}
export default Main;
