function disemvowel(str){
   return str.replace(/a|e|i|o|u/gi, "");
}