const fs=require('fs');
//fs.mkdirSync('demo'); //create sync directory
//fs.rmdirSync('demo')//Remove by sync call

fs.mkdir('demoasync',function(){
	fs.readFile('readMe.txt','utf-8',function(err,data)
	{if(err){
		console.write("Problem in reading File");
	}else{
		fs.writeFile('./demoasync/writeMe.txt',data,function(err)//async-Write call-non Blocking code  give next line unless finish
		{
			if (err)
				return console.log(err);
		});
		}
});
}); 
//removes the folder when its empty 
/* fs.unlink('./demoasync/writeMe.txt',function(){
	fs.rmdir('demoasync');
});
 */