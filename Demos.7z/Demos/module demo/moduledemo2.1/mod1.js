
	getData=function(){
		console.log("In GetData");
	};
	
	getLogin=function(){
		console.log("In GetLogin");
	};
	
	var data=23;
	


module.exports.getD=getData;
module.exports.getL=getLogin;
module.exports.temp=data;