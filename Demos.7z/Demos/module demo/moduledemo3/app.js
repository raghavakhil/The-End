var emp=require('./lib'); //If module is index give ./lib or else give full path 

emp.setEmpId(1001);
emp.setEmpName("Rahul Vikash");
emp.setEmpSalary(10021.44);

var printDetail=emp.getAllEmployee();
console.log(printDetail);