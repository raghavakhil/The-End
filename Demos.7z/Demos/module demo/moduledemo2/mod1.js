var hello={
	getData :function(){
		console.log("In GetData");
	},
	getLogin :function(){
		console.log("In GetLogin");
	}
	
};

module.exports=hello;