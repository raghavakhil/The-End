const event=require('events');
const util=require('util');

var Person= function(name){
	this.name=name;
}

util.inherits(Person,event.EventEmitter);

var person1=new Person("Vikash");
var person2=new Person("Rahul");
var person3=new Person("Ajay");

var people=[person1,person2,person3];

people.forEach(function(person){
	person.on('dep',function(msg){
		console.log(person.name+' department is '+msg)
	});
});

person1.emit('dep','JAVA');

