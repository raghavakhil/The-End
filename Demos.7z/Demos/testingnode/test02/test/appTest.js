const assert= require('chai').assert;
const sayHello=require('../app').sayHello;
const addNumber=require('../app').addNumber;

describe('App',function(){
    it('app should return hello',function(){
assert.equal(sayHello(),'hello');
    });
});

it('sayHello should return a string',function(){
let result=sayHello();
assert.typeOf(result,'string');
});
it('addnumber should be above 5',function(){
let result=addNumber(5,5);
assert.isAbove(result,5);
});

it('addnumber should return a number',function(){
    let result=addNumber(5,5);
    assert.typeOf(result,'number');
    });