function route(handle,pathname,response,reviewData){
    console.log('Routiing a request for'+pathname);
if(typeof handle[pathname]==='function'){
    handle[pathname](response,reviewData);
}else{
console.log('No handler for '+pathname);
response.writeHead(404,{"Content-Type":"text/plain"});
response.write("Page not Found....");
response.end();
}
}


exports.route=route;