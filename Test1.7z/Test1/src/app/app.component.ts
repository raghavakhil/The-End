import { Component } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Angular Form';
  constructor (private httpService: HttpClient) { }
  mobileArray: any [];
mobId:number;
mobName:string;
mobPrice:number;

/*************Mehtod for Deleting a particular row *********/
del(d){
       
       this.mobileArray.splice(d,1);

}

/***********Method for sorting MobileId*********/
sortId():void
{
    
    this.mobileArray.sort(function(a,b){
    if(a.mobId<b.mobId){
      return -1;
    }
    if(a.mobId>b.mobId){
      return 1;
    
    }
    
    return 0;
  
  })

};

/***********Method for sorting MobileName*********/
sortName():void
{
    
    this.mobileArray.sort(function(a,b){
    if(a.mobName<b.mobName){
      return -1;
    }
    if(a.mobName>b.mobName){
      return 1;
    }
    
      return 0; 
   
   })

};

/***********Method for sorting MobilePrice*********/
sortPrice():void
{
    
    this.mobileArray.sort(function(a,b){
    if(a.mobPrice<b.mobPrice){
      return -1;
    }
    if(a.mobPrice>b.mobPrice){
      return 1;
    }
   
    return 0;
  
   
   })

};
  ngOnInit () 
  {
  
  this.httpService.get('./assets/mobile.json').subscribe(
       
       data => {
        this.mobileArray = data as string [];	 
    },    
  
  )}

}
