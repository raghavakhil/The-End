import React, { Component } from 'react'; 
import ProjectDetails from './projectDetails'
class ProjectItems extends Component
{
   
    deleteProject(id){
        console.log("Deleted from Project Item");
        this.props.onDelete(id);
    }
    render()
    {
           let detail=this.props.project.Details.map((detail,index)=>{
               console.log(this.props.project.title);
               return (
                   <ProjectDetails key={this.props.project.title + index} detail={detail} id={index+1}/>
               )
           });

        return(
              <ul> 
                <li>{this.props.project.title}</li>
                 <li className="Projects">
                     <strong>{this.props.project.id}</strong>{this.props.project.category}
                </li>
                <li className="Hoo">
                    <title>category</title><a href="#"
                    onClick={this.deleteProject.bind(this,this.props.project.id)}>Delete</a>
                    </li>  
                 {detail}           
               </ul>

        );
    }
}
export default ProjectItems