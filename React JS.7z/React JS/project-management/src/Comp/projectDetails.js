import React, { Component } from 'react'; 
class ProjectDetails extends  Component
{
    render(){
        
   return (
      
      <div>
          <h3>Details {this.props.id}</h3>
         <ul>
             <li>{this.props.detail.Duration}</li>
            <li>{this.props.detail.Budget}</li>
         </ul>
      </div>
    );
  }
}
export default ProjectDetails