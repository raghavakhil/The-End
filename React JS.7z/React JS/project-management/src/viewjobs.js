import React, { Component } from 'react';
import hashHistory from 'react-router';
import './App.css';
import capgemini from './images/capgemini.png'
import { BrowserRouter as Router, Switch, Route, Link } from 'react-router-dom';
import axios from 'axios';
axios.defaults.baseURL = "http://localhost:8080";
class viewjobs extends Component {

    constructor(props) {
        super(props);
        this.state = {
            companyName: '', companyJob: '',
            companyloc: [],
        };
    }




    componentWillMount() {

        //get particular company details
        axios.post('/orgs/get/', { "companyId": "C002" }).then(response => {
            this.setState({ companyName: response.data[0].name })
            console.log(response.data[0].name);
        }).catch(function (error) {
            console.log(error);
        });

        axios.post('/orgs/position/', { "companyID": "C002", "jobId": "J002" }).then(response => {

            this.setState({ companyJob: response.data[0].profile.jobs[0].position })
            console.log(response.data[0].profile.jobs[0].position)
        }).catch(function (error) {
            console.log(error);
        });
        axios.post('/orgs/location/', { "companyID": "C002" }).then(response => {

            this.setState({ companyloc: response.data[0].profile.locations })
            console.log(this.state.companyloc);
        }).catch(function (error) {
            console.log(error);
        });


    }
    render() {

        return (
            <div class="card-deck">
                <div class="col-lg-4 py-2">
                    <div class="card h-100 text-black bg-light">
                        <div class="card-body">
                            <p class="card-title"><img src={capgemini} width="50px" /></p><br />
                            <table>
                                <tr><td><h6><Link to={'/jobdetails'}>{this.state.companyJob}</Link></h6></td></tr>
                                <tr><td><p class="cap">{this.state.companyName}</p></td></tr>

                                {this.state.companyloc.map(function (name, index) {
                                    return <li key={index}>{name}</li>;
                                })}


                            </table>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 py-2">
                    <div class="card h-100 text-black bg-light">
                        <div class="card-body">
                            <p class="card-title"><img src={capgemini} width="50px" /></p><br />
                            <table ><tr><td><h6>Senior Consultant</h6></td></tr>
                                <tr><td><p class="cap">Capgemini</p></td></tr>
                                <tr><td><p class="loc">Hyderabad,Telangana,India</p></td></tr>
                            </table>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 py-2">
                    <div class="card h-100 text-black bg-light">
                        <div class="card-body">
                            <p class="card-title"><img src={capgemini} width="50px" /></p><br />
                            <table ><tr><td><h6>Senior Consultant</h6></td></tr>
                                <tr><td><p class="cap">Capgemini</p></td></tr>
                                <tr><td><p class="loc">Hyderabad,Telangana,India</p></td></tr>
                            </table>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4 py-2">
                    <div class="card h-100 text-black bg-light">
                        <div class="card-body">
                            <p class="card-title"><img src={capgemini} width="50px" /></p><br />
                            <table ><tr><td><h6><a href="#jobs">Senior Consultant</a></h6></td></tr>
                                <tr><td><p class="cap"><a href="#jobs">Capgemini</a></p></td></tr>
                                <tr><td><p class="loc"><a href="#jobs">Hyderabad,Telangana,India</a></p></td></tr>
                            </table>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4 py-2">
                    <div class="card h-100 text-black bg-light">
                        <div class="card-body">
                            <p class="card-title"><img src={capgemini} width="50px" /></p><br />
                            <table ><tr><td><h6>Senior Consultant</h6></td></tr>
                                <tr><td><p class="cap">Capgemini</p></td></tr>
                                <tr><td><p class="loc">Hyderabad,Telangana,India</p></td></tr>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        )
    }
}
export default viewjobs;