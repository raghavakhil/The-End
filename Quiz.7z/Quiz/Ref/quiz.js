const questions={
		"question":"Which country recently honoured the first conquest of Mount Everest without bottled oxygen?",
		"option a":"India","option b":"UK","option c":"Nepal","option d":"China",
		"answer":"c"
},
{
	"question":"What was the theme of the 2018 World Earth Day?",
	"option a":"End Plastic Pollution","option b":"Save Mother Earth from Plastic",
	           "option c":"No to Plastic","option d":"Plastic Pollution: A Menac",
	"answer":"a"      
},
{
	"question":"Which country has agreed to halt its nuclear tests and ICBM launches?",
	"option a":"North Korea","option b":"Iran",
	           "option c":"China","option d":"Russia",
	"answer":"a"  
},
{
	"question":"Union Government is going to roll out initiative for prevention and control of which disease?",
	"option a":"Cholera","option b":"Dengue",
	           "option c":"Viral Hepatitis","option d":"Pneumonia",
	"answer":"c"
},
{
	"question":"How many languages are spoken in India?",
	"option a":"23","option b":"22",
	           "option c":"24","option d":"25",
	"answer":"b"
},
{
	"question":"Which of the following is an official language of Afghanistan?",
	"option a":"Pashto","option b":"Punjabi",
	            "option c":"Balochi","option d":"Urdu",
	"answer":"a"
},
{
	"question":"Which of the following is the oldest language in the world?",
	"option a":"Tamil","option b":"Sanskrit",
	           "option c":"French","option d":"Arabic",
	"answer":"a"
},
{
	"question":"Which of the following is not an official language of EU?",
    "option a":"Romanian","option b":"Bulgarian",
	           "option c":"Turkish","option d":"German",
	"answer":"c"
},
{
	"question":"Who was greatest writer of all the time?",
	"optiona":"Willam Faulkner","optionb":"Charles Dickens",
	           "optionc":"Shakespeare","optiond":"Jane Austen",
	"answer":"c"
},
{
	"question":"Which author won first Man Booker Prize?",
	"option a":"John Berger","option b":"Paul Scott",
	           "option c":"P H Newby","option d":"Keri Hulme",
	"answer":"c"
};