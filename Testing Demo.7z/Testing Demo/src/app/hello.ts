
export function helloworld(){
    return "Hello World"
}

export function greetMe(name){
    return "Hi " + name;
}

export function compute(number){
    if(number<0){
        return 2;
    }
    return number+1;
}

export class AuthSerive{
    isAuthenticated():boolean{
        return !!localStorage.getItem('token');
    }
}