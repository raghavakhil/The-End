import { TestBed, async, ComponentFixture } from '@angular/core/testing';
import { AppComponent } from './app.component'
import { DebugElement} from '@angular/core';
import {By} from '@angular/platform-browser'
describe("Testing App component", function () {
let app : AppComponent;
let comp : AppComponent;
let debugElement : DebugElement;
let fixture : ComponentFixture<AppComponent>;
let compElement;
 beforeEach(async()=>{
    TestBed.configureTestingModule(
        {declarations:[AppComponent]}
    ).compileComponents();
    
});

beforeEach(()=>{
     fixture = TestBed.createComponent(AppComponent);
    debugElement=fixture.debugElement;
    app = fixture.debugElement.componentInstance;
    comp = fixture.debugElement.componentInstance;
});

it("should Create App component",async()=>{
   
    expect(app).toBeTruthy();
});

it("Should define the name",()=>{
    expect(app.name).toEqual("Welcome Angular 2");
})

it("should have 3 entries in items",async()=>{
    expect(app.items.length).toBe(3);
})

it("check whether name is rendered in h1 tag",async()=>{
    fixture.detectChanges();
    compElement = fixture.debugElement.nativeElement;
    expect(compElement.querySelector("h1").textContent).toContain("Welcome")
})

it("should increment the value by 1 in temp",async()=>{
    debugElement.query(
        By.css("button.increment")).triggerEventHandler("click",null);

    fixture.detectChanges();
    const value = debugElement.query(By.css("h2")).nativeElement.innerText;
    expect(value).toBe('2');
})

});
