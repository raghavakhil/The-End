import {helloworld,greetMe,compute,AuthSerive} from './hello'
describe(
    "This suite is for Hello World", function () {

        let service : AuthSerive;

        beforeEach(()=>{
            service = new AuthSerive();
        });

        afterEach(()=>{
            service = null;
            localStorage.removeItem('token');
        })

        it("Hello fucntion return hello world", function () {
            expect(helloworld()).toEqual("Hello World");
        });

        it("greetme function is return name",function(){
            expect(greetMe("Sandeep")).toContain("Sandeep");
        }
        );

        it("Should increment the number if it is ve",function(){
            const result = compute(-1);
            expect(result).toBe(2);
        });

        it("test for the class fxn to return T",function(){
            localStorage.setItem('token','1234');
            expect(service.isAuthenticated()).toBeTruthy();
        });

         it("test for the class fxn to return False",function(){
            expect(service.isAuthenticated()).toBeFalsy();
        });


    }
);
