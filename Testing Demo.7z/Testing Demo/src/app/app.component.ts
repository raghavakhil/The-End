import { Component } from '@angular/core';

@Component({
  selector: 'my-app',
  template: `<h1>Hello {{name}}
  <br>
  <button (click)="increment()" class="increment">Increment</button>
  <button (click)="decrement()" class="decrement">Increment</button>
  </h1><hr>
  <h2>{{value}}</h2>
  `
})
export class AppComponent { 
  name = 'Welcome Angular 2'; 
  items : Array<string>;
  value=1;
  constructor(){
    this.items=['test','execute','to']
  }
  
  increment(){
    if(this.value < 15)
    this.value+=1;
  }
  decrement(){

    this.value--;
  }
}