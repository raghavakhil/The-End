import React, { Component } from 'react';

import './App.css';

class App extends Component {

     
  render() {
 return (
   <div className="Image">
     {this.props.isLoggedIn?
     
   (<img src={require('./proj/user.jpg')} alt="This is User"/>):
   (<img src={require('./proj/guest.jpg')} alt="This is Guest"/>)
   
     }

      </div>
    )}
  }
 

export default App;
