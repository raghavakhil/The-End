import React from 'react';

class Movie extends React.Component{
render(){
    return (
<div>
      {this.props.movieList.map(function(movieData,index){
          return (
<ul>
    <li><img src={movieData.imageUrl} alt={movieData.name}/></li>
    <li>{movieData.name}</li>
    <li>${movieData.price}</li>
</ul>

          )})
      }
      </div>
    )
}
}
export default Movie;