import React from 'react';
import './App.css';
var createReactClass = require('create-react-class');

var Welcome=createReactClass({
  render() {
    return (
      <div className="Welcome">
           <h1>Welcome to Capgemini!!</h1>
      </div>
    );
  }
  });

export default Welcome;
