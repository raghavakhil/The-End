import React from 'react';
import ReactDOM from 'react-dom';
import Parent from './parent' 



ReactDOM.render(<Parent>
		<br/>
		<button>register</button>
		<br/>
		This is a sample content
	</Parent>, document.getElementById('root'));

