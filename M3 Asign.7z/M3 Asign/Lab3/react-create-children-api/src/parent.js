import React from 'react';
var createReactClass = require("create-react-class");
var Parent = createReactClass({
 restrictParent() {
        try {
            React.Children.only(this.props.Children)
        }
        catch (error) {
            alert("Parent should have only 1 child element");
        }
    },
 render() {
        return (

            <div>
                a:Counting Child Components present in Parent Component :{React.Children.count(this.props.children)}
                <br /><br />
                b: Type of Child Component: {React.Children.map(
                    this.props.children, child => (
                        <i>
                            {child.type}
                        </i>
                    )
                )}

                <br /><br />
                c: The child Elements:
                {this.props.children}
                <br /><br />
                
                d:Restriction
                <br/>
                <button onClick={this.restrictParent}>React Parent</button>
            </div>
        )
    }
})

export default Parent





