import React from 'react';
import ReactDOM from 'react-dom';
import Parent from './parent' 



ReactDOM.render(<div><Parent>
	</Parent></div>, document.getElementById('root'));

