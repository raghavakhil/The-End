import React from 'react';


const createReactClass = require("create-react-class");

const Parent = createReactClass({
    render() {

        var childData=["Vivek","Rahul","Naveen","Sree"]
        var length=0;
        React.Children.forEach(childData,
        child=>(
            length++
        ));
        React.Children.forEach(this.props.children,
        child=>(
            console.log(child)
        ))
        return (
            <div>
                {this.props.children}
                {childData.map((child,index)=>(<h3>String:{child}||_Index:{index}||_Length of each string:{child.length}</h3>))}<br/>
                <h3>No. of strings available in array: {length}</h3>
            </div>
        );
    }
})

export default Parent;