import React, { Component } from 'react';
import './App.css';

import Mall from './Mall'

export const mallContext = React.createContext()

class movieMall extends Component {
  constructor(props) {
    super(props) 
    this.state = {
      theatre: 'Inox',
      screens: ['Tiger', 'Cheetah', 'Lion'],
      timings: ['9 PM', '1 PM', '5 PM']
    }
  }
  render() {
    return (
      <div className="App">
        <mallContext.Provider value={this.state}>
          <Mall />
        </mallContext.Provider>
      </div>
    );
  }
}

export default movieMall;
