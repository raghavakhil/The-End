import React from 'react';
import PropTypes from 'prop-types';

class Movie extends React.Component {
    render() {
        return (
            <div>
                <h3>
                {this.props.movieName}<br />
                {this.props.moviePrice}</h3>
            </div>
        )
    }
}

Movie.propTypes = {
    moviePrice: PropTypes.number.isRequired,
}
Movie.defaultProps = {
    movieName: "DEFAULT PRODUCT"
}

export default Movie;


