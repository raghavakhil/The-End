import React from 'react';
import ReactDOM from 'react-dom';
import Movie from './MovieList'
var name=undefined;
var price=250;

ReactDOM.render(<div>
	<Movie movieName={name} moviePrice={price} />
</div>, document.getElementById('root'));

