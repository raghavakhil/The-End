import React, { Component } from 'react';
import { mallContext } from './App'
import './App.css';
class Screen extends Component {

    showScreen(screen) {
        return <li key={screen}>{screen}</li>
    }

    showTimes(timing) {
        return <li key={timing}>{timing}</li>
    }

    render() {
        let screens = <mallContext.Consumer>
            {(context) => context.screens.map(screen => this.showScreen(screen))}
        </mallContext.Consumer>

        let times = <mallContext.Consumer>
            {(context) => context.timings.map(timing => this.showTimes(timing))}
        </mallContext.Consumer>

        return (
            <div class="container">
            <div class="list-group">
                Screen Name: <div class="list-group-item">{screens}</div>



                Show Times: <div class="list-group-item">{times}</div>
            </div>
            </div>
        );
    }
}

export default Screen;