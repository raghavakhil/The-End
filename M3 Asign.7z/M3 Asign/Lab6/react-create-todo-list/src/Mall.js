import React, { Component } from 'react';

import Theatre from './Theatre'

class Mall extends Component {
    render() { 
        return ( <Theatre /> );
    }
}
 
export default Mall;