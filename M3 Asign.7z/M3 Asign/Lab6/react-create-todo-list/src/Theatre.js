import React, { Component } from 'react';
import { mallContext } from './App'

import Screen from './Screen'

class Theatre extends Component {
    render() {
        return (
            <div>
                Theatre Name: &nbsp;
                    <mallContext.Consumer>
                        {(context) => context.theatre}
                    </mallContext.Consumer>
                    <br/><br/>
                <Screen />
            </div>
        );

    }
}

export default Theatre;
