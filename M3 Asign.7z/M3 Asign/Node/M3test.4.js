var express = require('express');
var exp = express();
var fs = require('fs');
/***********Inserting new Mobile Data into Existing data*/
exp.get('/insert', function (req, res) {
  var readData = fs.readFileSync('mobile.json');
  var mobileData = JSON.parse(readData);
  var newMobile = {
    "mobId": 1006,
    "mobName": "Motorola",
    "mobPrice": 15489,
  }
  mobileData.push(newMobile);//Pushing data into array
  res.send(mobileData)
  fs.writeFileSync('mobile.json', JSON.stringify(mobileData))
  console.log(mobileData);
})

exp.listen(4000, () => console.log('RUNNING........'))
