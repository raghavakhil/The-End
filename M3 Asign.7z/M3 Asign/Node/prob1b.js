var fs = require('fs');
var data = "Node Example";
fs.writeFile('temp.txt', data, function(err, data){
    if (err) console.log(err);
});
