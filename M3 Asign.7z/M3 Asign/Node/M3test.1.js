var express = require('express');
var exp = express();
var fs = require('fs');

/**************Displaying all mobile data */
exp.get('/get', function (req, res) {
    var readData = fs.readFileSync('mobile.json');
    var mobileData = JSON.parse(readData);
    console.log(mobileData);
    res.send(mobileData);//To display data in the browser
})
exp.listen(4000, () => console.log('RUNNING........'))