var express=require('express');
var exp=express();
var fs = require('fs');


exp.get('/get',function(req,res){
  var d=fs.readFileSync('emp.json');
  var data=JSON.parse(d);
  console.log(data);
  res.send(data);
})
exp.listen(3002, () => console.log('RUNNING........'))
