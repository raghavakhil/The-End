var express = require('express');
var exp = express();
var cors = require('cors');
var fs = require('fs');
var parser = require('body-parser');
 var MongoClient = require('mongodb').MongoClient
 var data = require('./emp.json')
 MongoClient.connect("mongodb://localhost:27017/test", function (err, dbEmp) {

        var emp = dbEmp.db('test');

        emp.collection('Employees').insert(data, true, function (err, res) {
            if (err) throw err;
            console.log("1 document inserted");
            dbEmp.close();
        });
    });