var express = require('express');
var exp = express();
var fs = require('fs');
/*************Updating mobile Name based on Id */
exp.get('/update', function (req, res) {
    var readData = fs.readFileSync('mobile.json');
    var mobileData = JSON.parse(readData);
    var a = new Array();
    var b = 0;
    for (var i of mobileData) {
        if (i.mobId == "1002") {
            i.mobName = "OnePlus"
            fs.writeFileSync('mobile.json', JSON.stringify(mobileData))
            console.log(i);
            a[b] = i;
            b++;
        }

    }
    res.send(a)
})

exp.listen(4000, () => console.log('RUNNING........'))
