var MongoClient = require('mongodb').MongoClient
MongoClient.connect("mongodb://localhost:27017/cgdb", function (err, dbvar) {

        var coll = dbvar.db('cgdb');
        var newData = { $set: { productName: "Paper", productCost:3,productDescription:"White" } };
        coll.collection("prod").updateOne({ "productID": "14" }, newData, function (err, res) {
            if (err) throw err;
            console.log("Data Updated based on ProductID");
            console.log(res);
            dbvar.close();
        });
    });
