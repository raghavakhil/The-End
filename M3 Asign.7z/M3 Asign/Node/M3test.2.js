var express = require('express');
var exp = express();
var fs = require('fs');
/**********Searching by price range*****/
exp.get('/sortPrice', function (req, res) {
  var readData = fs.readFileSync('mobile.json');
  var mobileData = JSON.parse(readData);
  var data = new Array();
  var b = 0;
  for (var i of mobileData) {
    if ((i.mobPrice >= 10000) && (i.mobPrice <= 50000)) {//Range between 10,000 to 50,000
      console.log(i);
      data[b] = i;
      b++;
    }

  }
  res.send(data)
})

exp.listen(4000, () => console.log('RUNNING........'))
