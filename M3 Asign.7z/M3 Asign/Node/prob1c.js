var http = require("http");
var express = require('express');
var app = express();
var bodyParser = require('body-parser');
var urlencodedParser = bodyParser.urlencoded({ extended: true });
 

var server = app.listen(4001, function () {
  var host = server.address().address
  var port = server.address().port
  console.log("Running....", host, port)
});
 
 
app.get('/form', function (req, res) {
  var html='';
  html +="<body>";
  html += "<form action='/result'  method='post'>";
  html += "<table>";
  html += "<tr><td>Name: </td><td><input type= 'text' name='name'></td></tr><br/>";
  html += "<tr><td>Password: </td><td><input type='password' name='password'></td></tr><br/>";
  html += "<tr><td><br/><input type='submit' value='submit'></td></tr>";
  html += "</table"; 
  html += "</form>";
  html += "</body>";
  res.send(html);
});
 
app.post('/result', urlencodedParser, function (req, res){
  var reply='';
  reply += "Your name is " + req.body.name+"<br/>";
  reply += "Your password  is " + req.body.password; 
  res.send(reply);
 });