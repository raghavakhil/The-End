var MongoClient = require('mongodb').MongoClient
/***************2-b Fetching all data in mongodb*******/
 MongoClient.connect("mongodb://localhost:27017/cgdb", function (err, dbvar) {

        var coll = dbvar.db('cgdb');
        coll.collection('prod').find().toArray( function (err, res) {
            if (err) throw err;
            console.log("Data Fetched");
            console.log(res);
            dbvar.close();
        });
    });