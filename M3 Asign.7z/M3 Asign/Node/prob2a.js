


/**************2-a Inserting static data into Database*******/

var MongoClient = require('mongodb').MongoClient
 MongoClient.connect("mongodb://localhost:27017/cgdb", function (err, dbvar) {

        var coll = dbvar.db('cgdb');
        var prodDetails=[
            {productID:"12",productName:"Pen",productCost:"15",productDescription:"Reynolds,Blue"},
            {productID:"13",productName:"Pencil",productCost:"10",productDescription:"Apsara"},
            {productID:"14",productName:"Book",productCost:"269",productDescription:"Paperback"},
            {productID:"15",productName:"Otg Cable",productCost:"75",productDescription:"Kingston,3.0 mbps"},
            {productID:"16",productName:"Pendrive",productCost:"348",productDescription:"Sony,128gb"},
        ]
        coll.collection('prod').insert(prodDetails, true, function (err, res) {
            if (err) throw err;
            console.log("1 document inserted");
            console.log(res);
            dbvar.close();
        });
    });


